import numpy as np
from scipy.optimize import curve_fit
import matplotlib.pyplot as plt
import cv2
from PIL import Image, ImageDraw, ImageFont
from transformers import DetrImageProcessor, DetrForObjectDetection
import torch
from concurrent.futures import ThreadPoolExecutor
from tqdm import tqdm

# Initialize the processor and model
processor = DetrImageProcessor.from_pretrained("facebook/detr-resnet-101", revision="no_timm")
model = DetrForObjectDetection.from_pretrained("facebook/detr-resnet-101", revision="no_timm")

# Set device to GPU if available
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model.to(device)

def parametric_curve(t, a, b, c, d, e, f):
    """参数化曲线模型"""
    x = a * t**2 + b * t + c
    y = d * t**2 + e * t + f
    return np.column_stack((x, y))

def fit_parametric_curve(points, times):
    """拟合参数化曲线"""
    points = np.array(points)
    times = np.array(times)
    
    def objective(t, a, b, c, d, e, f):
        return parametric_curve(t, a, b, c, d, e, f).flatten()
    
    initial_guess = [0, 0, points[0, 0], 0, 0, points[0, 1]]
    params, _ = curve_fit(objective, times, points.flatten(), p0=initial_guess)
    return params

def predict_position(params, t):
    """预测位置"""
    return parametric_curve(t, *params)

def calculate_distance_to_curve(point, params, t):
    """计算点到曲线的距离"""
    x, y = point
    x_pred, y_pred = predict_position(params, t)
    return np.sqrt((x - x_pred)**2 + (y - y_pred)**2)

def detect_objects(frame):
    image = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
    inputs = processor(images=image, return_tensors="pt").to(device)
    outputs = model(**inputs)
    target_size = torch.tensor([image.size[::-1]]).to(device)
    result = processor.post_process_object_detection(outputs, target_sizes=target_size, threshold=0.9)[0]
    
    ball_positions = []
    draw = ImageDraw.Draw(image)
    for score, label, box in zip(result["scores"], result["labels"], result["boxes"]):
        box = [round(i, 2) for i in box.tolist()]
        label_text = f"{model.config.id2label[label.item()]}: {round(score.item(), 3)}"
        if 'ball' in label_text:
            draw.rectangle(box, outline="red", width=3)
            ball_center = ((box[0] + box[2]) / 2, (box[1] + box[3]) / 2)
            ball_positions.append(ball_center)
    processed_frame = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2BGR)
    
    return processed_frame, ball_positions



def calculate_landing_point(params, frame_height):
    """计算落地点"""
    t = np.linspace(0, 10, 1000)  # 假设10秒内球一定会落地
    positions = predict_position(params, t)
    landing_indices = np.where(positions[:, 1] >= frame_height)[0]
    if len(landing_indices) > 0:
        return positions[landing_indices[0]]
    return None

def draw_ball_trajectory(frame, ball_positions, params, times):
    # 绘制实际球的位置
    for pos in ball_positions:
        cv2.circle(frame, (int(pos[0]), int(pos[1])), 5, (0, 255, 0), -1)
    
    # 如果有足够的点来拟合曲线，则绘制完整轨迹和预测落点
    if params is not None and len(times) >= 2:
        # 绘制完整轨迹
        t_vals = np.linspace(min(times), max(times) + 2, num=200)  # 延伸2秒
        predicted_positions = predict_position(params, t_vals)
        pts = np.array([pos for pos in predicted_positions if 0 <= pos[0] <= frame.shape[1] and 0 <= pos[1] <= frame.shape[0]], np.int32)
        if len(pts) > 1:
            cv2.polylines(frame, [pts], isClosed=False, color=(0, 0, 255), thickness=2)
        
        # 预测并绘制落地点
        landing_point = calculate_landing_point(params, frame.shape[0])
        if landing_point is not None:
            cv2.circle(frame, (int(landing_point[0]), int(landing_point[1])), 10, (255, 0, 0), -1)
            cv2.putText(frame, "Predicted Landing", (int(landing_point[0])-50, int(landing_point[1])-20), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 0, 0), 2)
    
    return frame

def detect_and_track_ball(input_video_path, output_video_path):
    cap = cv2.VideoCapture(input_video_path)
    frame_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    frame_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps = cap.get(cv2.CAP_PROP_FPS)
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    out = cv2.VideoWriter(output_video_path, cv2.VideoWriter_fourcc(*'mp4v'), fps, (frame_width, frame_height))

    progress_bar = tqdm(total=total_frames, desc='Processing Frames', unit='frames')

    ball_positions = []
    times = []
    params = None
    threshold = 50  # 偏离阈值
    min_points_for_fit = 5  # 拟合曲线所需的最小点数
    max_trajectory_points = 20  # 保留的最大轨迹点数
    frame_count = 0

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break
        
        processed_frame, positions = detect_objects(frame)

        if len(positions) > 0:
            current_time = frame_count / fps
            current_position = positions[0]
            
            if params is not None:
                predicted = predict_position(params, np.array([current_time]))[0]
                distance = np.linalg.norm(np.array(current_position) - predicted)
                
                if distance > threshold:
                    print(f"Ball trajectory changed at frame {frame_count}. Resetting trajectory.")
                    ball_positions = []
                    times = []
                    params = None
            
            ball_positions.append(current_position)
            times.append(current_time)
            
            if len(ball_positions) >= min_points_for_fit:
                params = fit_parametric_curve(ball_positions, times)
            
            # 如果轨迹点太多，只保留最近的一些点
            if len(ball_positions) > max_trajectory_points:
                ball_positions = ball_positions[-max_trajectory_points:]
                times = times[-max_trajectory_points:]

        processed_frame = draw_ball_trajectory(processed_frame, ball_positions, params, times)
        
        # 添加帧计数器到视频
        cv2.putText(processed_frame, f'Frame: {frame_count}', (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
        
        out.write(processed_frame)
        progress_bar.update(1)
        frame_count += 1

    cap.release()
    out.release()
    cv2.destroyAllWindows()
    progress_bar.close()
    print(f"Saved video with trajectory to {output_video_path}")
    
# Path to the input and output video
input_video_path = "video/3.mp4"
output_video_path = "video/output_video.mp4"

# Process video frames
detect_and_track_ball(input_video_path, output_video_path)