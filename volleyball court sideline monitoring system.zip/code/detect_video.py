import numpy as np
from scipy.optimize import curve_fit
import matplotlib.pyplot as plt
import cv2
from PIL import Image, ImageDraw, ImageFont
from transformers import DetrImageProcessor, DetrForObjectDetection
import torch
from concurrent.futures import ThreadPoolExecutor
from tqdm import tqdm

# Initialize the processor and model
processor = DetrImageProcessor.from_pretrained("facebook/detr-resnet-101", revision="no_timm")
model = DetrForObjectDetection.from_pretrained("facebook/detr-resnet-101", revision="no_timm")

# Set device to GPU if available
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model.to(device)

def quadratic(x, a, b, c):
    return a * x**2 + b * x + c

def fit_parabola(points):
    if len(points) < 3:
        return None
    x = np.array([p[0] for p in points])
    y = np.array([p[1] for p in points])
    params, _ = curve_fit(quadratic, x, y)
    return params

def predict_position(params, x):
    if params is None:
        return None
    return quadratic(x, *params)

def calculate_distance_to_parabola(point, params):
    """计算点到抛物线的距离"""
    x, y = point
    y_predicted = predict_position(params, x)
    return abs(y_predicted - y)

def detect_objects(frame):
    image = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
    inputs = processor(images=image, return_tensors="pt").to(device)
    outputs = model(**inputs)
    target_size = torch.tensor([image.size[::-1]]).to(device)
    result = processor.post_process_object_detection(outputs, target_sizes=target_size, threshold=0.9)[0]
    
    ball_positions = []
    draw = ImageDraw.Draw(image)
    for score, label, box in zip(result["scores"], result["labels"], result["boxes"]):
        box = [round(i, 2) for i in box.tolist()]
        label_text = f"{model.config.id2label[label.item()]}: {round(score.item(), 3)}"
        if 'ball' in label_text:
            draw.rectangle(box, outline="red", width=3)
            ball_center = ((box[0] + box[2]) / 2, (box[1] + box[3]) / 2)
            ball_positions.append(ball_center)
    processed_frame = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2BGR)
    
    return processed_frame, ball_positions

def draw_ball_trajectory(frame, ball_positions, params):
    for pos in ball_positions:
        cv2.circle(frame, (int(pos[0]), int(pos[1])), 5, (0, 255, 0), -1)
    if params is not None:
        # 绘制完整的抛物线
        x_vals = np.linspace(0, frame.shape[1], num=100)
        y_vals = quadratic(x_vals, *params)
        pts = np.array([np.array([x, y]) for x, y in zip(x_vals, y_vals) if 0 <= y <= frame.shape[0]], np.int32)
        pts = pts.reshape((-1, 1, 2))
        cv2.polylines(frame, [pts], isClosed=False, color=(0, 0, 255), thickness=2)
    return frame

def detect_and_track_ball(input_video_path, output_video_path):
    cap = cv2.VideoCapture(input_video_path)
    frame_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    frame_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps = cap.get(cv2.CAP_PROP_FPS)
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    out = cv2.VideoWriter(output_video_path, cv2.VideoWriter_fourcc(*'mp4v'), fps, (frame_width, frame_height))

    progress_bar = tqdm(total=total_frames, desc='Processing Frames', unit='frames')

    ball_positions = []
    current_trajectory_points = []
    params = None
    threshold = 50  # 偏离阈值

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break
        processed_frame, positions = detect_objects(frame)

        if len(positions) > 0:
            # 使用中值滤波器对检测结果进行平滑处理
            if len(ball_positions) > 3:
                ball_positions = [np.median(ball_positions, axis=0)]
            
            if params is not None:
                # 计算实际位置和抛物线的距离
                distance = calculate_distance_to_parabola(positions[0], params)
                if distance > threshold:
                    # 偏离太远，球被击打了，重新拟合抛物线
                    current_trajectory_points = []
                    params = None
                else:
                    # 偏离不远，修正轨迹，使用所有之前的点来拟合抛物线
                    current_trajectory_points.extend(ball_positions)
                    params = fit_parabola(current_trajectory_points)

            # 添加当前位置到轨迹列表，并进行预测
            ball_positions.append(positions[0])
            current_trajectory_points.append(positions[0])
            if len(current_trajectory_points) >= 3:
                params = fit_parabola(current_trajectory_points)

        processed_frame = draw_ball_trajectory(processed_frame, ball_positions, params)
        out.write(processed_frame)
        progress_bar.update(1)

    cap.release()
    out.release()
    cv2.destroyAllWindows()
    progress_bar.close()
    print(f"Saved video with bounding boxes to {output_video_path}")

# Path to the input and output video
input_video_path = "video/3.mp4"
output_video_path = "video/output_video.mp4"

# Process video frames
detect_and_track_ball(input_video_path, output_video_path)